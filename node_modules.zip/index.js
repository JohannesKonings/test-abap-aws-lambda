const abap = require('./src/zcl_index.clas.abap');

exports.handler = async (event) => {
	const response = new abap.zcl_index().run({
		method: request.method,
		path: request.url,
		query: '',
  });
  
  const headers = {};
	for (const h of response.get().headers.array()) {
		headers[h.get().field.get()] = h.get().value.get();
	}

	return new Response(response.get().body.get(), { headers });
};
