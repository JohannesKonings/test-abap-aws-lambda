# cloudflare-abap-template
Cloudflare worker ABAP template

## Running Template
`npm install`

`wrangler preview`

## Prerequsites
`npm i @cloudflare/wrangler -g`

Rust/Cargo installed

## Usage
`wrangler generate projectname https://github.com/open-abap/cloudflare-abap-template`
